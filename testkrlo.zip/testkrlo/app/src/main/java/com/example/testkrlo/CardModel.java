package com.example.testkrlo;

public class CardModel {
    private final int imageResId;

    public CardModel(int imageResId) {
        this.imageResId = imageResId;
    }

    public int getImageResId() {
        return imageResId;
    }
}
