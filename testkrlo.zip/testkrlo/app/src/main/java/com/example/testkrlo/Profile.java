package com.example.testkrlo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Profile extends AppCompatActivity {

    private TextView textViewName, textViewGender, textViewContactNumber;
    private TextView textViewMother, textViewFather, textViewBestFriend;

    private EditText editTextName, editTextGender, editTextContactNumber;
    private EditText editTextMother, editTextFather, editTextBestFriend;

    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        initializeViews();
        firebaseAuth = FirebaseAuth.getInstance();
        String userId = firebaseAuth.getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Fetch user data from Firebase
        fetchUserData();
    }

    @SuppressLint("WrongViewCast")
    private void initializeViews() {

        textViewName = findViewById(R.id.textViewName);
        textViewGender = findViewById(R.id.textViewGender);
        textViewContactNumber = findViewById(R.id.textViewContactNumber);
        textViewMother = findViewById(R.id.textViewMother);
        textViewFather = findViewById(R.id.textViewFather);
        textViewBestFriend = findViewById(R.id.textViewBestFriend);

        // EditTexts for saving data
        editTextName = findViewById(R.id.editTextName);
        editTextGender = findViewById(R.id.spinnerGender);
        editTextContactNumber = findViewById(R.id.editTextContactNumber);
        editTextMother = findViewById(R.id.editTextMother);
        editTextFather = findViewById(R.id.editTextFather);
        editTextBestFriend = findViewById(R.id.editTextBestFriend);
    }

    private void fetchUserData() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    UserData userData = snapshot.getValue(UserData.class);

                    if (userData != null) {
                        textViewName.setText("Name: " + userData.getName());
                        textViewGender.setText("Gender: " + userData.getGender());
                        textViewContactNumber.setText("Your Number: " + userData.getContactNumber());
                        textViewMother.setText("Mother: " + userData.getMother());
                        textViewFather.setText("Father: " + userData.getFather());
                        textViewBestFriend.setText("Best Friend: " + userData.getBestFriend());

                        ImageView profileImage = findViewById(R.id.circularprofile);
                        if (userData.getGender().equalsIgnoreCase("male")) {
                            profileImage.setImageResource(R.drawable.bit);
                        } else if (userData.getGender().equalsIgnoreCase("female")) {
                            profileImage.setImageResource(R.drawable.bitemoji3);
                        } else {
                            profileImage.setImageResource(R.drawable.pic3);
                        }
                    }
                } else {
                    Toast.makeText(Profile.this, "User data not found!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Profile", "Error fetching data: " + error.getMessage());
                Toast.makeText(Profile.this, "Failed to fetch data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveToFirebase() {
        String name = editTextName.getText().toString().trim();
        String gender = editTextGender.getText().toString().trim();
        String contactNumber = editTextContactNumber.getText().toString().trim();
        String mother = editTextMother.getText().toString().trim();
        String father = editTextFather.getText().toString().trim();
        String bestFriend = editTextBestFriend.getText().toString().trim();

        if (isInputValid(name, gender, contactNumber, mother, father, bestFriend)) {
            String userId = firebaseAuth.getCurrentUser().getUid();
            UserData user = new UserData(name, gender, contactNumber, mother, father, bestFriend);

            databaseReference.setValue(user)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(Profile.this, "Data saved successfully!", Toast.LENGTH_SHORT).show();
                            clearFields();
                            startActivity(new Intent(Profile.this, MainActivity.class));
                            finish();
                        } else {
                            Toast.makeText(Profile.this, "Error saving data: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        }
    }

    private boolean isInputValid(String... inputs) {
        for (String input : inputs) {
            if (TextUtils.isEmpty(input)) {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        if (!inputs[2].matches("\\d{10}")) { // Validate contact number
            Toast.makeText(this, "Enter a valid phone number!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void clearFields() {
        editTextName.setText("");
        editTextGender.setText("");
        editTextContactNumber.setText("");
        editTextMother.setText("");
        editTextFather.setText("");
        editTextBestFriend.setText("");
    }
}
