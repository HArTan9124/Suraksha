package com.example.testkrlo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class YourData extends AppCompatActivity {

    EditText editTextName, editTextContactNumber;
    EditText editTextMother, editTextFather, editTextBestFriend;
    Button buttonSave;
    TextView textViewDisplay;

    DatabaseReference databaseReference;
    FirebaseAuth mAuth;
    Spinner spinnerGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_data);

        initializeViews();

        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        setupGenderSpinner();

        buttonSave.setOnClickListener(v -> saveToFirebase());
    }

    private void initializeViews() {
        editTextName = findViewById(R.id.editTextName);
        editTextContactNumber = findViewById(R.id.editTextContactNumber);
        editTextMother = findViewById(R.id.editTextMother);
        editTextFather = findViewById(R.id.editTextFather);
        editTextBestFriend = findViewById(R.id.editTextBestFriend);
        buttonSave = findViewById(R.id.buttonSave);
        textViewDisplay = findViewById(R.id.textViewDisplay);
        spinnerGender = findViewById(R.id.spinnerGender);
    }

    private void setupGenderSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Male", "Female", "Other"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGender.setAdapter(adapter);
    }

    private void saveToFirebase() {
        String name = editTextName.getText().toString().trim();
        String gender = spinnerGender.getSelectedItem().toString();
        String contactNumber = editTextContactNumber.getText().toString().trim();
        String mother = editTextMother.getText().toString().trim();
        String father = editTextFather.getText().toString().trim();
        String bestFriend = editTextBestFriend.getText().toString().trim();

        if (!validateInputs(name, gender, contactNumber, mother, father, bestFriend)) return;

        String userId = mAuth.getCurrentUser().getUid();

        UserData userData = new UserData(name, gender, contactNumber, mother, father, bestFriend);

        databaseReference.child(userId).setValue(userData).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                displayMessage("Data saved successfully!");
                Toast.makeText(YourData.this, "Data saved successfully!", Toast.LENGTH_SHORT).show();
                clearFields();

                startActivity(new Intent(YourData.this, MainActivity.class));
                finish();
            } else {
                displayMessage("Error saving data: " + task.getException().getMessage());
                Toast.makeText(YourData.this, "Failed to save data!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validateInputs(String... inputs) {
        for (String input : inputs) {
            if (TextUtils.isEmpty(input)) {
                displayMessage("All fields are required!");
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
                return false;
            }
        }

        if (!isValidPhone(inputs[2])) {
            displayMessage("Invalid contact number format.");
            Toast.makeText(this, "Enter a valid phone number!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean isValidPhone(String phone) {
        return phone.matches("[0-9]{10}");
    }

    private void displayMessage(String message) {
        textViewDisplay.setText(message);
    }

    private void clearFields() {
        editTextName.setText("");
        spinnerGender.setSelection(0);
        editTextContactNumber.setText("");
        editTextMother.setText("");
        editTextFather.setText("");
        editTextBestFriend.setText("");
        textViewDisplay.setText("");
    }
}
