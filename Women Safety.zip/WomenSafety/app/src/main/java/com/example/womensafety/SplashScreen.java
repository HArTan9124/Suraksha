package com.example.womensafety;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class SplashScreen extends AppCompatActivity {

    private static final int SPLASH_DISPLAY_LENGTH = 2500; // Extended duration to align with Lottie animation
    private LottieAnimationView lottieView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        // Initialize the Lottie animation view
        lottieView = findViewById(R.id.lottieView);

        // Play Lottie animation programmatically (optional for further customization)
        lottieView.setRepeatCount(-1); // Loop the animation indefinitely

        // Delay for SPLASH_DISPLAY_LENGTH and decide where to navigate
        new Handler().postDelayed(() -> {
            // Check if the user is already logged in
            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

            if (isLoggedIn) {
                // Navigate to MainActivity
                startActivity(new Intent(SplashScreen.this, MainActivity.class));
            } else {
                // Navigate to LoginActivity
                startActivity(new Intent(SplashScreen.this, Login.class));
            }

            // Close SplashScreen activity
            finish();
        }, 5000);
    }
}
