package com.example.womensafety;

public class UserData {
    private String name, gender, contactNumber, mother, father, bestFriend;

    // Default constructor required for Firebase
    public UserData() {}

    public UserData(String name, String gender, String contactNumber, String mother, String father, String bestFriend) {
        this.name = name;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.mother = mother;
        this.father = father;
        this.bestFriend = bestFriend;

    }

    // Getters
    public String getName() { return name; }
    public String getGender() { return gender; }
    public String getContactNumber() { return contactNumber; }
    public String getMother() { return mother; }
    public String getFather() { return father; }
    public String getBestFriend() { return bestFriend; }

}
