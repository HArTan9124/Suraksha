package com.example.womensafety;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AboutUs extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        // Initialize social media buttons for the first card
        ImageButton linkedin1 = findViewById(R.id.linkedin);
        ImageButton instagram1 = findViewById(R.id.instagram);
        ImageButton git1 = findViewById(R.id.git);

        // Set click listeners for the first card
        linkedin1.setOnClickListener(view -> openUrl("https://www.linkedin.com/in/hartan9124/"));
        instagram1.setOnClickListener(view -> openUrl("https://www.instagram.com/tandon._.2895/"));
        git1.setOnClickListener(view -> openUrl("https://github.com/HArTan9124"));

        // Initialize social media buttons for the second card
        ImageButton linkedin2 = findViewById(R.id.linkedin2);
        ImageButton instagram2 = findViewById(R.id.instagram2);
        ImageButton git2 = findViewById(R.id.git2);

        // Set click listeners for the second card
        linkedin2.setOnClickListener(view -> openUrl("https://www.linkedin.com/in/sparsh-sharma-365593210/"));
        instagram2.setOnClickListener(view -> openUrl("https://www.instagram.com/sparsh0806/"));
        git2.setOnClickListener(view -> openUrl("https://github.com/sparsh-sharma-08"));

        // Initialize social media buttons for the third card
        ImageButton linkedin3 = findViewById(R.id.linkedin3);
        ImageButton instagram3 = findViewById(R.id.instagram3);
        ImageButton git3 = findViewById(R.id.git3);

        // Set click listeners for the third card
        linkedin3.setOnClickListener(view -> openUrl("https://www.linkedin.com/in/praval-pratap-singh-chauhan-91222028a/"));
        instagram3.setOnClickListener(view -> openUrl("https://www.instagram.com/pravalchauhan18/"));
        git3.setOnClickListener(view -> openUrl("https://github.com/Praval-Chauhan"));
    }

    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}
